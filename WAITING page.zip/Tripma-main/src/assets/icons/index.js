import menu from'./menu.png'
import close from './close.png'
import departure from './departure.png'
import arrival from './arrival.png'
import person from './personSolid.png'
import calendar from './calendar.png'
import right from './arrowRight.png'
import Star from './Star.png'
import Starblank from './Starblank.png'
import facebook from './facebook.png'
import iconfacebook from './iconfacebook.png'
import instagram from './instagram.png'
import twitter from './twitter.png'
import appStore from './appStore.png'
import googlePlay from './googlePlay.png'
import creditCard from './creditCard.png'



export {
    creditCard,
    appStore,
    googlePlay,
    menu,
    close,
    departure,
    arrival,
    person,
    calendar,
    right,
    Star,
    Starblank,
    facebook,
    iconfacebook,
    instagram,
    twitter
}