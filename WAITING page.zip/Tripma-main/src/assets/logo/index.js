import china from './AirChina.png'
import france from './AirFrance.png'
import delta from './DeltaAirlines.png'
import emirates  from './Emirates.png'
import eva from './EVAAir.png'
import hawaiian from './HawaiianAirlines.png'
import japan from './JapanAirlines.png'
import Korean from './KoreanAir.png'
import quantas from './QantasAirlines.png'
import united from './UnitedAirlines.png'
import tripma from './tripma.png'

export {
    china,
    france,
    delta,
    emirates,
    eva,
    hawaiian,
    japan,
    Korean,
    quantas,
    united,
    tripma
}